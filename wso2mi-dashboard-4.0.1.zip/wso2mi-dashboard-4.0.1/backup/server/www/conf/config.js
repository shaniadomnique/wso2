window.sso = {
    enable: false,
    config: {
    	clientID: "",
    	clientSecret: "",
    	serverOrigin: "",
    	resourceServerURLs: [],
    	signInRedirectURL: "",
    	storage: "webWorker",
    },
    usernameAttribute: "sub",
    adminGroupAttribute: "",
    allowedAdminGroups: [],
};
